<?php /* C:\xampp\htdocs\Student-Progress-Tracking\resources\views/lecturer/showProblem.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>การแจ้งเตือนปัญหา</title>
</head>
<body>

<?php $__currentLoopData = $risk_problem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show_problem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo e($show_problem->problem_detail); ?><br>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('bar.username', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('bar.header(lec)', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('bar.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>