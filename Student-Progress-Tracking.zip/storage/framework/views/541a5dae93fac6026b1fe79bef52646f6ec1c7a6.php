<?php /* C:\xampp\htdocs\Student-Progress-Tracking\resources\views/auth/login.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
    <link href="<?php echo e(asset('css/pagelogin.css')); ?>" rel="stylesheet" type="text/css">
    <title>Login Project</title>
    <meta charset="utf-8">
    <ul>
        <img src="../img/sit.png" width="370" height="50">
        <li><a href="http://kmutt.ac.th/"><p class="phead">King Mongkut's University of Technology Thonburi (KMUTT)</p></a></li>
    </ul>
</head>

<body>
<br><br><br><br>
    <div class="login">
        <div class="form">

            <h3>ระบบติดตามความก้าวหน้าของนักศึกษา</h3>
            <h4>Student Progress Tracking System</h4>


            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <input placeholder="Username" id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>

                <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                    <div class="col-md-6">
                        <input placeholder="Password" id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>

                            <input type="submit" value="Login" class="submit" >
                                <?php echo e(__('Login')); ?>


             </form>
    </div>
</div>

</body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>