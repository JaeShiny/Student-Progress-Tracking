<?php /* C:\xampp\htdocs\Student-Progress-Tracking\resources\views/advisor/adviseStudent.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $myStudent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo e($ad_list->bio->first_name); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('bar.header(ad)', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>