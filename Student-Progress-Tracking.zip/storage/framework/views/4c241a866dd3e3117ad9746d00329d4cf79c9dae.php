<?php /* C:\xampp\htdocs\Student-Progress-Tracking\resources\views/bar/footer.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>


</body>
<!-- Footer -->
<style>
    .footer {
      position: fixed;
      left: 0;
      bottom: 0;
      width: 100%;
      background-color: #1D5287;
      color: white;
      text-align: center;
    }

</style>

    <div class="footer">
      <!-- Copyright -->
        <div class="footer-copyright text-center py-3">
            © 2019 Copyright: 3Cha IT#22
        </div>
      <!-- Copyright -->
    </div>
  <!-- Footer -->

</html>
