<?php /* C:\xampp\htdocs\Student-Progress-Tracking\resources\views/EducationOfficer/curriculumall.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Curriculum</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

</head>

<body>
<div class="container">

    

 

 <?php $__currentLoopData = $curriculum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <?php if($curriculum->curriculum_id<5): ?>
 <div class="row">
        <div class="col-md-6"> Columns A

 

<br><br><br>
            <div class="card" style="width:400px">
                <img class="card-img-top" src="../img/curriculum.jpg" alt="Card image">
                <div class="card-body">
                    <h4 class="card-title"><?php echo e($curriculum->curriculum_name); ?></h4>
                    <p class="card-text"><?php echo e($curriculum->curri_name_eng); ?></p><br><br>
                    <a href="#" class="btn btn-primary">รายละเอียด</a>
                </div>
            </div>
        </div>
        <?php endif; ?>
 

 <?php if($curriculum->curriculum_id>5): ?>
 <div class="row">
        <div class="col-md-6"> Columns B

 <br><br><br>
            <div class="card" style="width:400px">
                <img class="card-img-top" src="../img/curriculum.jpg" alt="Card image">
                <div class="card-body">
                    <h4 class="card-title"><?php echo e($curriculum->curriculum_name); ?></h4>
                    <p class="card-text"><?php echo e($curriculum->curri_name_eng); ?></p><br><br>
                    <a href="#" class="btn btn-primary">รายละเอียด</a>
                </div>
            </div></div>
 <?php endif; ?>
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>
</body>
</html>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('bar.username', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('bar.header(edu)', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('bar.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>