<?php /* C:\xampp\htdocs\Student-Progress-Tracking\resources\views/bar/username.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ระบบติดตามความก้าวหน้าของนักศึกษา</title>
    <style>
        body {
            /* background-color: black; */
            /* background-image: -moz-element(../img/user.png); */
        }

        .t1 {
            float: right;
            width: 280px;
            height: 38px;
            text-align: center;
            /* background-color: black; */
            color: white;
        }
    </style>
</head>

<body>
    <div class="t1">
        <?php if(auth()->guard()->guest()): ?>
            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>

        <?php if(Route::has('register')): ?>

            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>

        <?php endif; ?>
        <?php else: ?>

            
            
            <?php echo e(Auth::user()->name); ?> <span class="caret"></span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <button type="button" class="btn">

                <a class="" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?></a>
            </button>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>

        <?php endif; ?>

    </div>

</body>

</html>
