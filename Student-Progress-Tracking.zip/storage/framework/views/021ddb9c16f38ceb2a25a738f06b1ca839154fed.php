<?php /* C:\xampp\htdocs\Student-Progress-Tracking\resources\views/EducationOfficer/curriculum.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/course.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/csste.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>หลักสูตรการศึกษา</title>

</head>
<body>
        <div class="container">

        <!--Table-->
        <table class="table table-striped w-auto">

        <!--Table head-->

        <thead>
          <tr>
            <th><center>ชื่อหลักสูตร(ภาษาไทย)</center></th>
            <th><center>ชื่อหลักสูตร(ภาษาอังกฤษ)</center></th>
            <th><center>ตัวย่อ</center></th>
          </tr>
        </thead>
        <!--Table head-->

        <!--Table body-->
        <tbody>

                <?php $__currentLoopData = $curriculum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="table-info">

            <td>
                <a href="/curr/<?php echo e($curriculum->curriculum_id); ?>">
                    <?php echo e($curriculum->curriculum_name); ?>

                </a>
            </td>
            <td>
                <a href="/curr/<?php echo e($curriculum->curriculum_id); ?>">
                    <?php echo e($curriculum->curri_name_eng); ?>

                </a>
            </td>
            <td>
                <a href="/curr/<?php echo e($curriculum->curriculum_id); ?>">
                &nbsp;&nbsp;<?php echo e($curriculum->curr_abbre); ?>&nbsp;&nbsp;
                </a>
            </td>

          </tr>
        </tbody>
        <!--Table body-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

      <!--Table-->
    </div>
</body>
</html>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('bar.username', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('bar.header(edu)', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('bar.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>