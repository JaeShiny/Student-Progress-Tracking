<?php

namespace App\Model\mis;

use Illuminate\Database\Eloquent\Model;

class Generation extends Model
{
    //
}
