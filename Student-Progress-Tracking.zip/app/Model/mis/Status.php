<?php

namespace App\Model\mis;

use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    //
}
