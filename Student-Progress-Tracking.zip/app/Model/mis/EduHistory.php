<?php

namespace App\Model\mis;

use Illuminate\Database\Eloquent\Model;

class EduHistory extends Model
{
    //
}
