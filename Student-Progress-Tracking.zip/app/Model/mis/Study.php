<?php

namespace App\Model\mis;

use Illuminate\Database\Eloquent\Model;

class Study extends Model
{
    //
}
