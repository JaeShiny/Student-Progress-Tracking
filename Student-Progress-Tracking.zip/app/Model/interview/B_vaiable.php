<?php

namespace App\Model\interview;

use Illuminate\Database\Eloquent\Model;

class B_vaiable extends Model
{
    //
}
