<?php

namespace App\Model\interview;

use Illuminate\Database\Eloquent\Model;

class B_queue extends Model
{
    //
}
