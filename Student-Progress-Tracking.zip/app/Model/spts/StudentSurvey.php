<?php

namespace App\Model\spts;

use Illuminate\Database\Eloquent\Model;

class StudentSurvey extends Model
{
    //
}
