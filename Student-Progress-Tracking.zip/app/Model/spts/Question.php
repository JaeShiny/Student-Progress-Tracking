<?php

namespace App\Model\spts;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    //
}
