<?php

namespace App\Model\spts;

use Illuminate\Database\Eloquent\Model;

class Answer extends Model
{
    //
}
